/** Automatically generated file. DO NOT MODIFY */
package com.example.fragementstest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}