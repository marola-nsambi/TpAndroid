/** Automatically generated file. DO NOT MODIFY */
package com.example.tp1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}