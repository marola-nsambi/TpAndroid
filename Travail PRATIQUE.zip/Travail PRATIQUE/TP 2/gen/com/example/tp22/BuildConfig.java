/** Automatically generated file. DO NOT MODIFY */
package com.example.tp22;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}